package com.fernandocejas.sample.core.functional
